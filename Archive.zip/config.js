const firebaseConfig = {
  apiKey: "AIzaSyCH5M38DFEcJGW3n94hDM3n4akgEgKDoRA",
  authDomain: "scada-beb30.firebaseapp.com",
  databaseURL: "https://scada-beb30.firebaseio.com",
  projectId: "scada-beb30",
  storageBucket: "scada-beb30.appspot.com",
  messagingSenderId: "400122545130",
  appId: "1:400122545130:web:a0574f70b4cc3de4"
};
module.exports = firebaseConfig;